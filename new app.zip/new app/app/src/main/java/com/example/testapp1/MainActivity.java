package com.example.testapp1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.Optional;

public class MainActivity extends AppCompatActivity {
    private Camera camera;
    private boolean isPreview=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (!android.os.Environment.getExternalStorageState().equals(  //判断手机是否安装SD卡
                android.os.Environment.MEDIA_MOUNTED)) {
            Toast.makeText(this, "请安装SD卡！", Toast.LENGTH_SHORT).show(); // 提示安装SD卡
        }

        Button button=(Button) findViewById(R.id.button1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Toast.makeText(MainActivity.this,"已点击button1",Toast.LENGTH_SHORT).show();
            }
        });
        Button button2=(Button) findViewById(R.id.button4);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Toast.makeText(MainActivity.this,"已点击button4",Toast.LENGTH_SHORT).show();
            }
        });

        ActivityCompat.requestPermissions(MainActivity.this, new String[]{
                Manifest.permission.CAMERA,
                Manifest.permission.WRITE_EXTERNAL_STORAGE},1);

        /*open the camera*/
        SurfaceView surfaceView = (SurfaceView) findViewById(R.id.surfaceView);
        final SurfaceHolder surfaceHolder=surfaceView.getHolder();
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        Button preview=(Button)findViewById(R.id.button2);
        Button takePicture=(Button)findViewById(R.id.button3);

        preview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!isPreview){
                    camera= android.hardware.Camera.open();
                    isPreview=true;
                }
                try {
                    camera.setPreviewDisplay(surfaceHolder);
                    Camera.Parameters parameters=camera.getParameters();

                    parameters.setPictureFormat(PixelFormat.JPEG);
                    parameters.set("jpeg-quality",80);

                    camera.setParameters(parameters);
                    camera.startPreview();
                    camera.autoFocus(null);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });



        takePicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(camera!=null){
                    camera.takePicture(null,null,jpeg);
                }
            }
        });
    }

    final Camera.PictureCallback jpeg=new Camera.PictureCallback() {

        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            Bitmap bitmap = BitmapFactory.decodeByteArray(data,0,data.length);
            camera.stopPreview();
            isPreview=false;

            File appDir = new File(Environment.getExternalStorageDirectory(),"/DCIM/Camera/");
            if (!appDir.exists()){
                appDir.mkdir();
            }
            String fileName=System.currentTimeMillis()+".jpg";
            File file=new File(appDir,fileName);

            try{
                FileOutputStream fos=new FileOutputStream(file);
                bitmap.compress(Bitmap.CompressFormat.JPEG,100,fos);
                fos.flush();
                fos.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                MediaStore.Images.Media.insertImage(MainActivity.this.getContentResolver(),
                        file.getAbsolutePath(), fileName, null);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

            // 最后通知图库更新
            MainActivity.this.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
                    Uri.parse("file://" + "")));
            Toast.makeText(MainActivity.this, "照片保存至：" + file, Toast.LENGTH_LONG).show();
            resetCamera(); //调用重新预览resetCamera()方法
        }
    };
    private void resetCamera() {     //创建resetCamera()方法，实现重新预览功能
        if (!isPreview) {            //如果为非预览模式
             camera.startPreview();    //开启预览
             isPreview = true;
        }
    }

    @Override
    protected void onPause() {  //当暂停Activity时，停止预览并释放资源
        if (camera != null) {        //如果相机不为空
             camera.stopPreview();    //停止预览
             camera.release();        //释放资源
        }
        super.onPause();
    }

}